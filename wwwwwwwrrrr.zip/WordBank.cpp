#include "WordBank.h"

WordBank::WordBank()
{
    
}

void WordBank::ReturnGenres()
{

}

string WordBank::GetWord()
{

}

void WordBank::AddWord(const string& filename)
{

}